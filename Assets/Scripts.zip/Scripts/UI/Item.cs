using UnityEngine;

[CreateAssetMenu(menuName = "ArcticBloom/Item", fileName = "NewItem")]
public class Item : ScriptableObject
{
    [Header("ID � ������")]
    public string id;
    public string displayName;
    public Sprite icon;

    [Header("����")]
    public bool stackable = true;
    public int maxStack = 99;
}
